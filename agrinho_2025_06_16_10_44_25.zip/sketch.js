let bonecoX = 50; // Posição inicial do boneco no eixo X
let bonecoY = 250; // Posição inicial do boneco no eixo Y (altura)
let velocidadeBoneco = 1; // Velocidade que o boneco anda

let nuvemX1 = 100; // Posição inicial da primeira nuvem
let nuvemX2 = 300; // Posição inicial da segunda nuvem
let velocidadeNuvem = 0.5; // Velocidade das nuvens

let chegou = false; // Variável para controlar se o boneco chegou

function setup() {
  createCanvas(600, 400); // Cria uma tela de 600 por 400 pixels
}

function draw() {
  // --- Céu e Chão Rural ---
  background(135, 206, 250); // Céu azul claro
  fill(100, 200, 70); // Cor verde para o campo
  rect(0, 280, width, height - 280); // Campo verde
  fill(139, 69, 19); // Cor marrom para uma estrada de terra
  rect(0, 310, width, 70); // Estrada de terra

  // --- Desenha o Sol ---
  fill(255, 220, 0); // Cor amarela alaranjada para o sol
  noStroke(); // Sem borda
  ellipse(550, 50, 80, 80); // Círculo para o sol

  // --- Desenha as Nuvens ---
  fill(255, 255, 255, 200); // Cor branca para as nuvens, um pouco transparente
  noStroke();
  // Nuvem 1
  ellipse(nuvemX1, 80, 70, 50);
  ellipse(nuvemX1 + 30, 70, 70, 50);
  ellipse(nuvemX1 - 30, 90, 70, 50);
  // Nuvem 2
  ellipse(nuvemX2, 120, 60, 40);
  ellipse(nuvemX2 + 20, 110, 60, 40);
  ellipse(nuvemX2 - 20, 130, 60, 40);

  // Move as nuvens
  nuvemX1 += velocidadeNuvem;
  nuvemX2 += velocidadeNuvem;

  // Reinicia as nuvens quando saem da tela
  if (nuvemX1 > width + 50) {
    nuvemX1 = -50;
  }
  if (nuvemX2 > width + 50) {
    nuvemX2 = -50;
  }

  // --- Desenha Árvores (simples) ---
  fill(100, 50, 0); // Tronco marrom
  rect(150, 200, 20, 80); // Tronco 1
  rect(350, 190, 20, 90); // Tronco 2
  fill(34, 139, 34); // Folhas verde escuro
  ellipse(160, 190, 80, 80); // Copa 1
  ellipse(360, 180, 90, 90); // Copa 2

  // --- Desenha a Farmácia Rural (Mais Bonita) ---
  // Base da farmácia
  fill(205, 133, 63); // Cor de madeira mais clara/avermelhada
  rect(430, 180, 150, 120); // Corpo principal da farmácia

  // Telhado Duplo
  fill(139, 0, 0); // Cor do telhado (vermelho escuro)
  triangle(410, 180, 590, 180, 500, 100); // Telhado maior
  fill(160, 0, 0); // Telhado um pouco mais escuro para a parte de trás
  triangle(420, 180, 580, 180, 500, 110); // Telhado ligeiramente menor, para dar efeito 3D

  // Detalhe da frente/pórtico
  fill(222, 184, 135); // Cor de madeira mais clara para o detalhe
  rect(480, 260, 40, 40); // Base pequena na frente

  // Porta
  fill(80, 40, 10); // Cor da porta de madeira
  rect(490, 240, 40, 60); // Porta
  // Maçaneta
  fill(180); // Cor cinza para a maçaneta
  ellipse(520, 270, 5, 5);

  // Janelas (com moldura)
  // Janela esquerda
  fill(173, 216, 230); // Azul claro para o vidro
  rect(440, 200, 35, 35);
  noFill(); // Sem preenchimento para a moldura
  stroke(80, 40, 10); // Cor da moldura
  strokeWeight(2); // Espessura da moldura
  rect(440, 200, 35, 35); // Moldura
  line(440, 217.5, 475, 217.5); // Divisor horizontal
  line(457.5, 200, 457.5, 235); // Divisor vertical

  // Janela direita
  fill(173, 216, 230);
  noStroke(); // Volta a não ter borda para o vidro
  rect(525, 200, 35, 35);
  noFill();
  stroke(80, 40, 10);
  strokeWeight(2);
  rect(525, 200, 35, 35);
  line(525, 217.5, 560, 217.5);
  line(542.5, 200, 542.5, 235);
  noStroke(); // Desliga a borda para não afetar o resto do desenho

  // Cruz da farmácia (no telhado)
  fill(255); // Cor branca para a cruz
  rect(495, 130, 10, 25); // Haste vertical da cruz
  rect(485, 140, 30, 10); // Haste horizontal da cruz

  // --- Desenha o Boneco (simplificado) ---
  fill(0); // Cor preta
  ellipse(bonecoX, bonecoY, 30, 30); // Cabeça
  rect(bonecoX - 5, bonecoY + 15, 10, 50); // Corpo
  rect(bonecoX - 15, bonecoY + 30, 10, 30); // Braço esquerdo
  rect(bonecoX + 5, bonecoY + 30, 10, 30); // Braço direito
  rect(bonecoX - 10, bonecoY + 65, 10, 30); // Perna esquerda
  rect(bonecoX, bonecoY + 65, 10, 30); // Perna direita

  // --- Lógica de Movimento e Mensagem ---
  // Move o boneco
  bonecoX += velocidadeBoneco;

  // Verifica se o boneco chegou
  if (bonecoX >= 400 && !chegou) { // Se o boneco está na posição e ainda não "chegou"
    velocidadeBoneco = 0; // Para o boneco
    chegou = true; // Define que ele chegou
  }

  // Se o boneco chegou, exibe as mensagens
  if (chegou) {
    fill(0); // Cor preta para o texto
    textSize(24); // Tamanho da fonte
    textAlign(CENTER); // Alinhamento central do texto

    // Mensagem 1
    text("Cheguei na farmácia!", width / 2, height / 2 - 50);

    // Mensagem 2 (um pouco abaixo)
    textSize(18); // Pode ser um tamanho diferente
    text("Missão cumprida!", width / 2, height / 2);
  }
}